@include('admin::panel.fields.ckeditor')
